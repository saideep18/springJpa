package com.cg.exception;

import org.apache.log4j.Logger;

public class AccountException extends Exception{
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(AccountException.class);
	String msg;
	public AccountException(String msg) {
		this.msg= msg;
	}
	
	public String getMessage(){
		logger.info("Exception type = AccountException occurred");
		return msg;
	}
}
