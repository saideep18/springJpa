package com.cg.exception;

import org.apache.log4j.Logger;

public class AccountBalanceException extends Exception {
	private static final long serialVersionUID = 1L;
	static Logger logger = Logger.getLogger(AccountBalanceException.class);
	String msg;
	public AccountBalanceException(String msg){
		this.msg = msg;
	}
	
	public String getMessage(){
		logger.info("Exception type = AccountBalanceException occurred");
		return msg;
	}
}