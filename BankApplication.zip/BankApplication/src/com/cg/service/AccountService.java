package com.cg.service;

import java.util.ArrayList;
import com.cg.bean.AccountHolder;
import com.cg.exception.AccountBalanceException;
import com.cg.exception.AccountException;


public interface AccountService {

	public long addAccount(AccountHolder acc);
	public long depositMoney(long accNumber, long money) throws AccountException;
	public long withdrawMoney(long accNumber,long money) throws AccountException, AccountBalanceException;
	public String fundTransfer(long accNumber,long receiverAccNumber, long money) throws AccountException, AccountBalanceException;
	public ArrayList<String> showTransactions(long accNumber);
	public AccountHolder showBalance(long accNumber) throws AccountException;
	public AccountHolder showDetails(long accNumber) throws AccountException;
}
