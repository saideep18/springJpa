package com.cg.service;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.bean.AccountHolder;
import com.cg.dao.AccountDao;
import com.cg.dao.AccountDaoImpl;
import com.cg.exception.AccountBalanceException;
import com.cg.exception.AccountException;

public class AccountServiceImpl implements AccountService {
	
	static Logger logger = Logger.getLogger(AccountServiceImpl.class);
	
	AccountDao dao;
	public AccountServiceImpl()
	{
		dao = new AccountDaoImpl();
	}
	@Override
	public long addAccount(AccountHolder acc){
		logger.info("Delegating to addAccount method in dao");
		return dao.addAccount(acc);
	}
	
	@Override
	public long depositMoney(long accNumber, long money) throws AccountException {
		logger.info("Delegating to depositMoney method in dao");
		return dao.depositMoney(accNumber,money);
	}

	@Override
	public long withdrawMoney(long accNumber, long money) throws AccountException, AccountBalanceException {
		logger.info("Delegating to withdrawMoney method in dao");
		return dao.withdrawMoney(accNumber,money);
	}

	@Override
	public String fundTransfer(long accNumber,long receiverAccNumber, long money) throws AccountException, AccountBalanceException{
		logger.info("Delegating to fundTransfer method in dao");
		return dao.fundTransfer(accNumber, receiverAccNumber, money);
	}

	@Override
	public ArrayList<String> showTransactions(long accNumber) {	
		logger.info("Delegating to showTransaction method in dao");
		return dao.showTransactions(accNumber);
	}

	@Override
	public AccountHolder showBalance(long accNumber) throws AccountException{
		logger.info("Delegating to showBalance method in dao");
		return dao.showBalance(accNumber);
	}
	
	@Override
	public AccountHolder showDetails(long accNumber) throws AccountException{
		logger.info("Delegating to showDetails method in dao");
		return dao.showDetails(accNumber);
	}
	
	public boolean validateName(String name) {
		logger.info("Validating name");
		String nameformat = "[A-Z][a-z]{1,20}";
		if(name.matches(nameformat))
			return true;
		else
			return false;
	}
	public boolean validatePanDetails(String panNumber) {
		logger.info("Validating PAN number");
		String panNumberFormat="[A-Z]{1,6}[0-9]{1,6}";
		if(panNumber.matches(panNumberFormat))
			return true;
		else
			return false;
	}
	public boolean validatePhoneNumber(long phoneNo) {
		logger.info("Validating Phone number");
		String phoneNoFormat ="[0-9]{10}";
		if(Long.toString(phoneNo).matches(phoneNoFormat))
			return true;
		else
			return false;
	}
	public boolean validateAddress(String addr) {
		logger.info("Validating Address");
		String addressFormat = "[A-Z][a-z]{1,20}";
		if(addr.matches(addressFormat))
			return true;
		else
			return false;
	}
	public boolean validateGender(String gender) {
		logger.info("Validating Gender");
		String genderFormat = "[M,F]";
		if(gender.matches(genderFormat))	
			return true;
		else
			return false;	
	}
	
}
