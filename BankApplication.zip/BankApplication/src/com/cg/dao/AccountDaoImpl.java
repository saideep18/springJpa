package com.cg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.cg.bean.AccountHolder;
import com.cg.exception.AccountBalanceException;
import com.cg.exception.AccountException;

public class AccountDaoImpl implements AccountDao {
	
	static Logger logger = Logger.getLogger(AccountDaoImpl.class);
	
	ArrayList<String> list;
	Map<Long,AccountHolder> map;
	public AccountDaoImpl()
	{
		list = new ArrayList<String>();
		map = new HashMap<Long,AccountHolder>();
	}
	
	@Override
	public long addAccount(AccountHolder acc){
		logger.info("in method addAccount in Dao layer");
		long id = (long) ((Math.random()*10)+1);
		map.put(id, acc);
		return id;
	}
	
	@Override
	public long depositMoney(long accNumber,long money) throws AccountException {
		logger.info("in method depositMoney in Dao layer");
		if(!map.containsKey(accNumber)){
			logger.error("Account number :"+accNumber+" doesn't exist");
			throw new AccountException("Account Number "+accNumber +" Not found, please provide correct Account Number!");
		}
		AccountHolder acc = map.get(accNumber);
		long balance= acc.getBalance();
		balance += money;
		acc.setBalance(balance);
		map.put(accNumber, acc);
		list.add("Money deposited : "+money+" Available Balance : "+balance+" for acc: "+accNumber+" ");
		return balance;
	}

	@Override
	public long withdrawMoney(long accNumber,long money) throws AccountBalanceException, AccountException {
		logger.info("in method withdrawMoney in Dao layer");
		if(!map.containsKey(accNumber)){
			logger.error("Account number :"+accNumber+" doesn't exist");
			throw new AccountException("Account Number "+accNumber +" Not found, please provide correct Account Number!");
		}
		AccountHolder acc = map.get(accNumber);
		long minBalance = 500;
		long balance = acc.getBalance();
		if((balance-money)<minBalance){
			logger.error("Min Balance not found! Balance: "+balance+" User tried to withdraw: "+money);
			throw new AccountBalanceException("You don't have sufficient acount balance for this transaction!");
		}
		else{
			balance=balance - money;
			logger.info("Account number :"+accNumber+" has a balance of: "+balance);
			list.add("Money withdrawn: "+money+" Available Balance : "+balance+" for acc: "+accNumber);
		}
		acc.setBalance(balance);
		map.put(accNumber, acc);
		return balance;
	}

	@Override
	public String fundTransfer(long accNumber,long receiverAccNumber, long money) throws AccountBalanceException, AccountException{
		logger.info("in method fundTransfer in Dao layer");
		if(!map.containsKey(accNumber)||!map.containsKey(receiverAccNumber)){
			logger.error("Account number :"+accNumber+" doesn't exist");
			throw new AccountException("Account Number "+receiverAccNumber +" Not found, please provide correct Account Number!");
		}
		long transaction = withdrawMoney(accNumber, money);
		depositMoney(receiverAccNumber, money);
		logger.info("Money amount transferred: "+money);
		list.add("Money transferred from acc: "+accNumber+" to acc: "+receiverAccNumber+". Amount transferred: "+money+" to acc: "+receiverAccNumber+" ");
		list.add("Balance present in acc: "+accNumber+" is: "+transaction);
		return "Succefully transferred";
	}

	@Override
	public ArrayList<String> showTransactions(long accNumber) {
		logger.info("in method showTransaction in Dao layer");
		return list;
	}
	@Override
	public AccountHolder showBalance(long accNumber) throws AccountException {
		logger.info("in method showBalance in Dao layer");
		if(!map.containsKey(accNumber)){
			logger.error("Account number :"+accNumber+" doesn't exist");
			throw new AccountException("Account Number "+accNumber +" Not found, please provide correct Account Number!");
		}	
		AccountHolder acc = map.get(accNumber);
		return acc;
	}

	@Override
	public AccountHolder showDetails(long accNumber) throws AccountException{
		logger.info("in method showDetails in Dao layer");
		if(!map.containsKey(accNumber)){
			logger.error("Account number :"+accNumber+" doesn't exist");
			throw new AccountException("Account Number "+accNumber +" Not found, please provide correct Account Number!");
		}
		AccountHolder acc = map.get(accNumber); 
		return acc;
	}
}
