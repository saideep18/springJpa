package com.cg.ui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.Scanner;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.bean.AccountHolder;
import com.cg.exception.AccountBalanceException;
import com.cg.exception.AccountException;
import com.cg.service.AccountServiceImpl;

public class Main {
	
	static Logger logger = Logger.getLogger(Main.class);
	
	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		Scanner scn = new Scanner(System.in);
		AccountServiceImpl service = new AccountServiceImpl();
		logger.info("in main");
		int choice = 0;
		do{
			String name = "";
			String dateOfBirth="";
			String panNumber="";
			long phoneNo=0;
			String addr="";
			long accNumber = 0;
			String gender;
			System.out.println("Welcome to xyz bank wallet application!");
			System.out.println("1. Add account in our bank!");
			System.out.println("2. Deposit money in your account");
			System.out.println("3. Withdraw money from your account");
			System.out.println("4. Trnsfer money");
			System.out.println("5. Show balance in your account");
			System.out.println("6. Show user details!");
			System.out.println("7. Show transactions for this account!");
			System.out.println("Enter your choice!");
			try{
			choice = scn.nextInt();
			if(choice ==1){
				logger.info("choice given: "+choice);
				System.out.println("Welcome  to adding account screen!");
				while(true){
					System.out.println("Please enter your name: ");
					name = scn.next();
					boolean isValid = service.validateName(name);
					if(isValid == true)
						break;
					else
						System.out.println("Please enter name in correct format!");
				}
				while(true){
					System.out.println("Enter your gender: ");
					gender=scn.next();
					boolean isValid = service.validateGender(gender);
					if(isValid == true)
						break;
					else
						System.out.println("Please enter correct gender! M/F");
				}
				while(true){
					System.out.println("Enter your Date of birth: ");
					dateOfBirth = scn.next();
					DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
					Date d= null;
					try {
						d = df.parse(dateOfBirth);
					} catch (ParseException e) {
						e.printStackTrace();
					}
					dateOfBirth = df.format(d);
					break;
				}
				while(true){
					System.out.println("Enter PAN number: ");
					panNumber=scn.next();
					boolean isValid = service.validatePanDetails(panNumber);
					if(isValid == true)
						break;
					else
						System.out.println("Please enter correct PAN number!");
				}
				while(true){
					System.out.println("Enter your Phone Number here: ");
					phoneNo = scn.nextLong();
					boolean isValid = service.validatePhoneNumber(phoneNo);
					if(isValid == true)
						break;
					else
						System.out.println("Please enter correct phone number!");
				}
				while(true){
					System.out.println("Enter your address here: ");
					addr = scn.next();
					boolean isValid = service.validateAddress(addr);
					if(isValid == true)
						break;
					else
						System.out.println("Please enter correct address!");
				}
						
				AccountHolder bean = new AccountHolder();
				bean.setAccNumber(accNumber);
				bean.setBalance(0);
				bean.setAccHolderName(name);
				bean.setPanNumber(panNumber);
				bean.setDate(dateOfBirth);
				bean.setAccHolderAddr(addr);
				bean.setPhoneNo(phoneNo);
				bean.setGender(gender);
						
				long accNo = service.addAccount(bean);
					System.out.println("New account created with Account Number: " +accNo);
				}
				else if(choice ==2){
					logger.info("choice given: "+choice);
					System.out.println("Enter your Account Number here: ");
					accNumber = scn.nextLong();
					System.out.println("Enter the money to be deposited in this account: ");
					long money = scn.nextLong();
				 	long balance=0;
					try {
						balance = service.depositMoney(accNumber,money);
						if(balance!=0){
					 		System.out.println("Money successfully added to your wallet!");
					 		System.out.println("The balance in your acc is: "+balance);
					 	}
					} catch (AccountException e) {
						System.out.println(e.getMessage());
					}	 			 				
				}
				else if(choice ==  3){
					logger.info("choice given: "+choice);
					System.out.println("Enter your Account Number here: ");
					accNumber = scn.nextLong();
					System.out.println("Enter the money to be withdrawed from this account: ");
					long money = scn.nextLong();
					long balance=0;
					try {
						balance = service.withdrawMoney(accNumber,money);
						System.out.println("The balance in your acc is: "+balance);
					} catch (AccountException e) {
						System.out.println(e.getMessage());
					} catch (AccountBalanceException e) {
						System.out.println(e.getMessage());
					}
				}
				else if(choice == 4){
					logger.info("choice given: "+choice);
					System.out.println("Enter your account number here: ");
					accNumber = scn.nextLong();
					System.out.println("Enter the amount to be trasferred: ");
					long money = scn.nextLong();
					System.out.println("Enter receiver account number here: ");
					long receiverAccNumber = scn.nextLong();
					String msg="";
					try {
						msg = service.fundTransfer(accNumber, receiverAccNumber, money);
						System.out.println(msg);
					} catch (AccountException e) {
						System.out.println(e.getMessage());
					} catch (AccountBalanceException e) {
						System.out.println(e.getMessage());
					}
				}
				else if(choice == 5){
					logger.info("choice given: "+choice);
					System.out.println("Enter your account number here: ");
					accNumber = scn.nextLong();
					AccountHolder acc=null;
					try {
						acc = service.showBalance(accNumber);
						System.out.println("Balance in your account is: "+acc.getBalance());
					} catch (AccountException e) {
						System.out.println(e.getMessage());
					}
				}
				else if(choice == 6){
					logger.info("choice given: "+choice);
					System.out.println("Enter your account number here: ");
					accNumber = scn.nextLong();
					AccountHolder acc = null;
					try {
						acc = service.showDetails(accNumber);
						System.out.println("User account number: "+acc.getAccNumber());
						System.out.println("Account Holder name: "+acc.getAccHolderName());
						System.out.println("Account Holder gender: "+acc.getGender());
						System.out.println("Account Holder address: "+acc.getAccHolderAddr());
						System.out.println("Account holder contact number: "+acc.getPhoneNo());
						System.out.println("Account holder Date of Birth: "+acc.getDate());
						System.out.println("Account Holder PAN Number: "+acc.getPanNumber());
					} catch (AccountException e) {
						System.out.println(e.getMessage());
					}
				}
				else if(choice == 7){
					logger.info("choice given: "+choice);
					System.out.println("Enter your account number here: ");
					System.out.println("All transactions are shown below: ");
					ArrayList<String> list = service.showTransactions(accNumber);
					Iterator<String> itr = list.iterator();
					while(itr.hasNext())
						System.out.println(itr.next());
				}
				else
					System.out.println("Enter the correct choice from the menu!");
		System.out.println("Do you want to continue? 0- No");	
		choice = scn.nextInt();
		}catch(InputMismatchException e){
			logger.error("User entered non numerical value: "+choice);
			System.out.println("Please provide the proper numerical input for choice! Exiting now!");
		}
		}while(choice!= 0);
		scn.close();
	}
}
