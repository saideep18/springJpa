package com.cg.lms.exceptions;

public class LMSException extends Exception {

	public LMSException(String message) {
		super(message);
	}
}
