package com.cg.lms.service;

import java.util.List;

import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;

public interface ILMSService {

	int addBookDetails(BookDetails book);

	List<BookDetails> getAllBooks();

	BookDetails getBookById(int id)throws LMSException;

	BookDetails deleteBookDetailsById(int id) throws LMSException;

	//BookDetails deleteBookDetailsById(int id) throws LMSException;
}
