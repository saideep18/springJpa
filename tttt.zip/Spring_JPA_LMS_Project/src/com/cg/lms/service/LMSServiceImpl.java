package com.cg.lms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.lms.dao.ILMSDao;
import com.cg.lms.exceptions.LMSException;
import com.cg.lms.model.BookDetails;

@Service
@Transactional
public  class LMSServiceImpl implements ILMSService {

	@Autowired
	ILMSDao lmsDao;

	@Override
	public int addBookDetails(BookDetails book) {
		return lmsDao.addBook(book);

	}

	@Override
	public List<BookDetails> getAllBooks() {
		return lmsDao.getAllBooks();
	}

	@Override
	public BookDetails getBookById(int id)throws LMSException {
		return lmsDao.getBookDataBydId(id);
	}

	@Override
	public BookDetails deleteBookDetailsById(int id) throws LMSException {
		// TODO Auto-generated method stub
		return lmsDao.deleteBookDetailsById(id);
	}

}
