package com.cg.spring.service;

import java.util.ArrayList;

import com.cg.spring.exception.AccountBalanceException;
import com.cg.spring.exception.AccountCreateException;
import com.cg.spring.exception.AccountException;
import com.cg.spring.model.Account;

public interface IBankService {
	public int addAccount(Account acc) throws AccountCreateException;

	public int depositMoney(int accNumber, int money) throws AccountException;

	public int withdrawMoney(int accNumber, int money) throws AccountException, AccountBalanceException;

	public String fundTransfer(int accNumber, int receiverAccNumber, int money)
			throws AccountException, AccountBalanceException;

	public ArrayList<String> showTransactions(int accNumber) throws AccountException;

	public int showBalance(int accNumber) throws AccountException;

	public Account showDetails(int accNumber) throws AccountException;
}
