package com.cg.spring.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="AllTransactions")
public class Transactions {


	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int TransactionId;
	
	@Column(name = "AccID")
	private int accNumber;
	
	@Column(name = "Transactions")
	private String transactions;
	
	public Transactions() {
		
	}
	
	
	public Transactions(int transactionId, int accNumber, String transactions) {
		super();
		TransactionId = transactionId;
		this.accNumber = accNumber;
		this.transactions = transactions;
	}


	public int getTransactionId() {
		return TransactionId;
	}


	public void setTransactionId(int transactionId) {
		TransactionId = transactionId;
	}


	public int getAccNumber() {
		return accNumber;
	}


	public void setAccNumber(int accNumber) {
		this.accNumber = accNumber;
	}


	public String getTransactions() {
		return transactions;
	}


	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}
	
	
	
	
}
