package com.cg.bankapplication.controller;

import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.bankapplication.exception.AccountException;
import com.cg.bankapplication.model.Account;
import com.cg.bankapplication.service.IBankService;

@Controller
public class MainController {

	@Autowired
	IBankService service;

	// First Page
	@RequestMapping("/home")
	public String addPage() {
		String view = "menu";
		return view;
	}

	// Account creation
	@RequestMapping("/add")
	public String addAccountScreen(Model model) {
		String view = "addAccount";
		model.addAttribute("Account", new Account());
		return view;
	}

	@RequestMapping(value = "/accountAdded", method = RequestMethod.POST)
	public String AccountIdGenerator(Model model, @Valid @ModelAttribute("Account") Account account,
			BindingResult result) {
		String view = "";
		if (result.hasErrors())
			view = "addAccount";
		else {
			try {
				int id = service.addAccount(account);
				model.addAttribute("accountId", id);
				view = "idGenerated";
			} catch (AccountException e) {
				model.addAttribute("error", e.getMessage());
				view = "errorPage";
			}
		}
		return view;
	}

	// Money deposit
	@RequestMapping("/deposit")
	public String depositScreen() {
		String view = "depositMoney";
		return view;
	}

	@RequestMapping(value = "/moneyDeposited", method = RequestMethod.POST)
	public String moneyDeposited(Model model, @RequestParam("accountId") int accountId,
			@RequestParam("money") int money) {
		String view = "";
		try {
			int accBalance = service.depositMoney(accountId, money);
			model.addAttribute("accountBalance", accBalance);
			view = "balanceScreen";
		} catch (AccountException e) {
			model.addAttribute("error", e.getMessage());
			view = "errorPage";
		}
		return view;
	}

	// Money withdraw
	@RequestMapping("/withdraw")
	public String withdrawScreen() {
		String view = "withdraw";
		return view;
	}

	@RequestMapping(value = "/moneyWithdrawed", method = RequestMethod.POST)
	public String moneyWithdrawed(Model model, @RequestParam("accountId") int accountId,
			@RequestParam("money") int money) {
		String view = "";
		try {
			int accBalance = service.withdrawMoney(accountId, money);
			model.addAttribute("accountBalance", accBalance);
			view = "balanceScreen";
		} catch (AccountException e) {
			model.addAttribute("error", e.getMessage());
			view = "errorPage";
		}
		return view;
	}

	// Fund Transfer
	@RequestMapping("/transfer")
	public String transferScreen() {
		String view = "fundTransfer";
		return view;
	}

	@RequestMapping(value = "/fundTransfer", method = RequestMethod.POST)
	public String transferMoney(Model model, @RequestParam("accountId") int accountId,
			@RequestParam("receiverAccountId") int receiverId, @RequestParam("money") int money) {
		String view = "";
		try {
			String transfer = service.fundTransfer(accountId, receiverId, money);
			model.addAttribute("transferMessage", transfer);
			view = "success";
		} catch (AccountException e) {
			model.addAttribute("error", e.getMessage());
			view = "errorPage";
		}
		return view;
	}

	// Fetch balance
	@RequestMapping("/balance")
	public String showBalanceScreen() {
		String view = "showBalance";
		return view;
	}

	@RequestMapping(value = "/availableBalance", method = RequestMethod.POST)
	public String availableBalance(Model model, @RequestParam("accountId") int accountId) {
		String view = "showAvailableBalance";
		try {
			int balance = service.showBalance(accountId);
			model.addAttribute("balance", balance);
			view = "balanceValue";
		} catch (AccountException e) {
			model.addAttribute("error", e.getMessage());
			view = "errorPage";
		}
		return view;
	}

	// Fetch User details
	@RequestMapping("/details")
	public String showDetails() {
		String view = "showDetails";
		return view;
	}

	@RequestMapping("/availableDetails")
	public String availableDetails(Model model, @RequestParam("accountId") int accountId) {
		String view = "";
		try {
			Account acc = service.showDetails(accountId);
			model.addAttribute("accountDetails", acc);
			view = "userData";
		} catch (AccountException e) {
			model.addAttribute("error", e.getMessage());
			view = "errorPage";
		}
		return view;
	}

	// Show all transactions
	@RequestMapping("/transactions")
	public String transactionScreen() {
		String view = "transactionPage";
		return view;
	}

	@RequestMapping(value = "/showTransactions", method = RequestMethod.POST)
	public String allTransaction(Model model, @RequestParam("accountId") int id) {
		String view = "";
		try {
			ArrayList<?> list = service.showTransactions(id);
			if (list.isEmpty())
				model.addAttribute("transaction", null);
			else
				model.addAttribute("transaction", list);
			view = "allTransactions";
		} catch (AccountException e) {
			model.addAttribute("error", e.getMessage());
			view = "errorPage";
		}
		return view;
	}
}