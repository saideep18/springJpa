package com.cg.bankapplication.service;

import java.util.ArrayList;

import com.cg.bankapplication.exception.AccountException;
import com.cg.bankapplication.model.Account;

public interface IBankService {
	public int addAccount(Account acc) throws AccountException;

	public int depositMoney(int accNumber, int money) throws AccountException;

	public int withdrawMoney(int accNumber, int money) throws AccountException;

	public String fundTransfer(int accNumber, int receiverAccNumber, int money)
			throws AccountException;

	public ArrayList<?> showTransactions(int accNumber) throws AccountException;

	public int showBalance(int accNumber) throws AccountException;

	public Account showDetails(int accNumber) throws AccountException;
}
