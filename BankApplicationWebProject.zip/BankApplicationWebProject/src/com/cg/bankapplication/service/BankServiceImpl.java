package com.cg.bankapplication.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.bankapplication.dao.BankDAOImpl;
import com.cg.bankapplication.exception.AccountException;
import com.cg.bankapplication.model.Account;

@Service
@Transactional
public class BankServiceImpl implements IBankService {

	@Autowired
	BankDAOImpl dao;

	@Override
	public int addAccount(Account acc) throws AccountException {
		// logger.info("Inside addAccount in service");
		return dao.addAccount(acc);
	}

	@Override
	public int depositMoney(int accNumber, int money) throws AccountException {
		// logger.info("Inside depositMoney in service");
		return dao.depositMoney(accNumber, money);
	}

	@Override
	public int withdrawMoney(int accNumber, int money) throws AccountException, AccountException {
		// logger.info("Inside withdrawMoney in service");
		return dao.withdrawMoney(accNumber, money);
	}

	@Override
	public String fundTransfer(int accNumber, int receiverAccNumber, int money)
			throws AccountException{
		// logger.info("Inside fundTransfer in service");
		return dao.fundTransfer(accNumber, receiverAccNumber, money);
	}

	@Override
	public ArrayList<?> showTransactions(int accNumber) throws AccountException {
		// logger.info("Inside showTransfer in service");
		return dao.showTransactions(accNumber);
	}

	@Override
	public int showBalance(int accNumber) throws AccountException {
		// logger.info("Inside showBalance in service");
		return dao.showBalance(accNumber);
	}

	@Override
	public Account showDetails(int accNumber) throws AccountException {
		// logger.info("Inside showDetails in service");
		return dao.showDetails(accNumber);
	}
}
