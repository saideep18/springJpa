package com.cg.bankapplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "Account_info")
public class Account {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "AccID")
	private Integer accNumber;

	@Column(name = "HolderName")
	@Pattern(regexp="[A-Za-z\\s]+", message="Name should consist of only Characters")
	private String accHolderName;

	@Column(name = "DOB")
	@NotEmpty(message="Should not be empty")
	private String date;

	@Column(name = "Gender")
	@NotEmpty(message="Should not be empty")
	private String gender;

	@Column(name = "PAN")
	@Pattern(regexp="[A-Z]{5}[0-9]{4}[A-Z]", message="PAN Number format: 5 Characters 4 Numbers 1 character")
	private String panNumber;

	@Column(name = "Address")
	@Pattern(regexp="[A-Za-z\\s]+", message="Address should consist of only Characters")
	private String accHolderAddr;

	@Column(name = "Balance")
	private Integer balance;

	@Column(name = "Contact")
	private Long phoneNo;

	public Account() {

	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getAccHolderAddr() {
		return accHolderAddr;
	}

	public void setAccHolderAddr(String accHolderAddr) {
		this.accHolderAddr = accHolderAddr;
	}

	public Integer getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(Integer accNumber) {
		this.accNumber = accNumber;
	}

	public Integer getBalance() {
		return balance;
	}

	public void setBalance(Integer balance) {
		this.balance = balance;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Account(Integer accNumber, String accHolderName, String date, String gender, String panNumber,
			String accHolderAddr, Integer balance, Long phoneNo) {
		super();
		this.accNumber = accNumber;
		this.accHolderName = accHolderName;
		this.date = date;
		this.gender = gender;
		this.panNumber = panNumber;
		this.accHolderAddr = accHolderAddr;
		this.balance = balance;
		this.phoneNo = phoneNo;
	}

}