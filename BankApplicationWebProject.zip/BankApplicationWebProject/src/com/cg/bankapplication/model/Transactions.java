package com.cg.bankapplication.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AllTransactions")
public class Transactions {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer TransactionId;

	@Column(name = "AccID")
	private Integer accNumber;

	@Column(name = "Transactions")
	private String transactions;

	@Column(name = "ReceiverID")
	private Integer receiverId;

	@Column(name = "Amount")
	private Integer money;

	public Transactions() {

	}

	public Integer getMoney() {
		return money;
	}

	public void setMoney(Integer money) {
		this.money = money;
	}

	public Integer getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(Integer transactionId) {
		TransactionId = transactionId;
	}

	public Integer getReceiverId() {
		return receiverId;
	}

	public void setReceiverId(Integer receiverId) {
		this.receiverId = receiverId;
	}

	public Integer getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(Integer accNumber) {
		this.accNumber = accNumber;
	}

	public String getTransactions() {
		return transactions;
	}

	public void setTransactions(String transactions) {
		this.transactions = transactions;
	}

	public Transactions(Integer transactionId, Integer accNumber, String transactions, Integer receiverId,
			Integer money) {
		super();
		TransactionId = transactionId;
		this.accNumber = accNumber;
		this.transactions = transactions;
		this.receiverId = receiverId;
		this.money = money;
	}

}
