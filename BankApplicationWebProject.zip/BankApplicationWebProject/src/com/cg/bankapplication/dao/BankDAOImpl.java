package com.cg.bankapplication.dao;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;

import com.cg.bankapplication.exception.AccountException;
import com.cg.bankapplication.model.Account;
import com.cg.bankapplication.model.Transactions;

@Repository
public class BankDAOImpl implements IBankDAO {

	@PersistenceContext
	EntityManager manager;

	Transactions transactions;

	// Create account
	@Override
	public int addAccount(Account acc) throws AccountException {
		acc.setBalance(1000);
		manager.persist(acc);
		int id = getAccountId();
		if (id == 0)
			throw new AccountException("Account creation failed!");
		return id;
	}

	// get Account ID after creation
	public int getAccountId() throws AccountException {
		int id = 0;
		String jpql = "Select max(acc.accNumber) from Account acc";
		Query query = manager.createQuery(jpql);
		id = (int) query.getSingleResult();
		return id;
	}

	// Money deposit into acc
	@Override
	public int depositMoney(int accNumber, int money) throws AccountException {
		// check if id is valid
		int bal = 0;
		boolean isValid = isIdPresent(accNumber);
		if (isValid == true) {
			bal = fetchBalanceFromDB(accNumber);
			bal = bal + money;

			// Crud operation to find record
			Account acc = manager.find(Account.class, accNumber);
			acc.setBalance(bal);

			// adding transaction details
			transactions = new Transactions();
			transactions.setAccNumber(accNumber);
			transactions.setMoney(money);
			transactions.setTransactions("Deposit");
			manager.persist(transactions);

			// fetching balance from database
			bal = fetchBalanceFromDB(accNumber);
		} else
			throw new AccountException("Account doesn't exist!");
		return bal;
	}

	// withdrawing money from account
	@Override
	public int withdrawMoney(int accNumber, int money) throws AccountException{
		int minBalance = 500;
		int bal = 0;
		// check if accountid is valid
		boolean isValid = isIdPresent(accNumber);
		if (isValid == true) {
			bal = fetchBalanceFromDB(accNumber);
			if ((bal - money) < minBalance)
				throw new AccountException("Insufficient balance for this transaction");
			else
				bal = bal - money;

			// storing new balance
			Account acc = manager.find(Account.class, accNumber);
			acc.setBalance(bal);
			transactions = new Transactions();
			transactions.setAccNumber(accNumber);
			transactions.setMoney(money);
			transactions.setTransactions("Withdraw");
			manager.persist(transactions);

			// fetching new balance
			bal = fetchBalanceFromDB(accNumber);
		} else
			throw new AccountException("Account doesn't exist!");
		return bal;
	}

	// Transferring mopney from one account to another account
	@Override
	public String fundTransfer(int accNumber, int receiverAccNumber, int money)
			throws AccountException{
		boolean isValid = isIdPresent(accNumber);
		if (isValid == true) {
			isValid = isIdPresent(receiverAccNumber);
			if (isValid == true) {
				withdrawMoney(accNumber, money);
				depositMoney(receiverAccNumber, money);
				transactions = new Transactions();
				transactions.setAccNumber(accNumber);
				transactions.setReceiverId(receiverAccNumber);
				transactions.setMoney(money);
				transactions.setTransactions("Money Transfer");
				manager.persist(transactions);
			}
		}
		return "fund transfer successful";
	}

	// Show transaction on the basis of id
	@Override
	public ArrayList<?> showTransactions(int accNumber) throws AccountException {
		boolean isValid = isIdPresent(accNumber);
		if (isValid == true) {
			String jpql = "select trans from Transactions trans where trans.accNumber= :accId";
			Query query = manager.createQuery(jpql);
			query.setParameter("accId", accNumber);
			ArrayList<?> list = (ArrayList<?>) query.getResultList();
			return list;
		} else
			throw new AccountException("Account doesn't exist!");
	}

	// showing balance to user
	@Override
	public int showBalance(int accNumber) throws AccountException {

		int bal = 0;
		boolean isValid = isIdPresent(accNumber);
		if (isValid == true) {
			bal = fetchBalanceFromDB(accNumber);
		} else
			throw new AccountException("Account doesn't exist!");
		return bal;
	}

	// Showing account details to user
	@Override
	public Account showDetails(int accNumber) throws AccountException {
		Account acc;
		boolean isValid = isIdPresent(accNumber);
		if (isValid == true) {
			String jpql = "Select acc from Account acc where acc.accNumber = :accNum";
			TypedQuery<Account> query = manager.createQuery(jpql, Account.class);
			query.setParameter("accNum", accNumber);
			acc = query.getSingleResult();
		} else
			throw new AccountException("Account doesn't exist!");
		return acc;
	}

	// Validation for Accountid in database
	public boolean isIdPresent(int accountId) {
		String jpql = "Select acc.accNumber from Account acc";
		Query query = manager.createQuery(jpql);
		List<?> list = (List<?>) query.getResultList();
		if (list.contains(accountId))
			return true;
		else
			return false;
	}

	// fetching the balance from the database
	public int fetchBalanceFromDB(int accNumber) {
		String jpql = "Select acc.balance from Account acc where acc.accNumber = :accNum";
		TypedQuery<Integer> query = manager.createQuery(jpql, Integer.class);
		query.setParameter("accNum", accNumber);
		int bal = query.getSingleResult();
		return bal;
	}
}
