package com.cg.bean;

public class AccountHolder {
	private String accHolderName;
	private String date;
	private String gender;
	private String panNumber;
	private String accHolderAddr;
	private long accNumber;
	private long balance;
	private long phoneNo;

	public AccountHolder()
	{
		
	}

	public String getAccHolderName() {
		return accHolderName;
	}

	public void setAccHolderName(String accHolderName) {
		this.accHolderName = accHolderName;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getPanNumber() {
		return panNumber;
	}

	public void setPanNumber(String panNumber) {
		this.panNumber = panNumber;
	}

	public String getAccHolderAddr() {
		return accHolderAddr;
	}

	public void setAccHolderAddr(String accHolderAddr) {
		this.accHolderAddr = accHolderAddr;
	}

	public long getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}
	
	public long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	public AccountHolder(String accHolderName, String date, String panNumber,
			String accHolderAddr, long accNumber) {
		super();
		this.accHolderName = accHolderName;
		this.date = date;
		this.panNumber = panNumber;
		this.accHolderAddr = accHolderAddr;
		this.accNumber = accNumber;
	}
	
}
