package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bean.AccountHolder;
import com.cg.exception.AccountBalanceException;
import com.cg.exception.AccountException;
import com.cg.exception.AccountCreateException;
import com.cg.exception.TableException;
import com.cg.util.DBUtil;

public class AccountDaoImpl implements AccountDao {
	Connection con;
	ArrayList<String> list;
	ArrayList<Long> accNo;
	
	public AccountDaoImpl()
	{
		con = DBUtil.getConnect();
		list = new ArrayList<>();
		accNo = new ArrayList<>();
	}
	
	@Override
	public long addAccount(AccountHolder acc) throws AccountCreateException, TableException{
		long id =0;
		try {
			String sql = "INSERT into ACCOUNT values(acc_seq.NEXTVAL,?,?,?,?,?,?,?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, acc.getAccHolderName());
			pstmt.setString(2, acc.getGender());
			pstmt.setString(3, acc.getDate());
			pstmt.setString(4, acc.getPanNumber());
			pstmt.setLong(5, acc.getPhoneNo());
			pstmt.setString(6, acc.getAccHolderAddr());
			pstmt.setLong(7, acc.getBalance());
			int row = pstmt.executeUpdate();
			if(row == 1)
				id = getAccountId();
			else
				throw new AccountCreateException("Unable to create account!");
		} catch (SQLException e) {
			throw new TableException("Unable to complete your request!");
		}
		return id;
	}
	
	public long getAccountId() throws AccountCreateException, TableException{	//Fetches the acount ID
		long id=0;
		String sql = "SELECT acc_seq.CURRVAL FROM dual";
		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			if(rs.next())
				id= rs.getLong(1);
			else
				throw new AccountCreateException("Unable to generate Id");
		} catch (SQLException e) {
			throw new TableException("Unable to complete your request!");
		}
		return id;
	}
	
	@Override
	public long depositMoney(long accNumber,long money) throws AccountException, TableException {	
		boolean isValid = isAccountValid(accNumber);
		if(isValid == false)
			throw new AccountException("This account number: "+accNumber+" is invalid");
		long balance = 0;
		String sql1 = "UPDATE Account SET HolderBal = ? WHERE HolderId = ?";
		String sql2 = "SELECT HolderBal FROM Account WHERE HolderId = ? ";
		try {	
			//Getting the balance for the acc from the table
			PreparedStatement pstmt = con.prepareStatement(sql2);
			pstmt.setLong(1, accNumber);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
				balance = rs.getLong(1);
			balance = balance + money;
			
			//Updating the new balance into the account
			pstmt = con.prepareStatement(sql1);
			pstmt.setLong(1, balance);
			pstmt.setLong(2, accNumber);
			int row = pstmt.executeUpdate();
			if(row == 1) {
				list.add("Money amount:"+money+ " diposited to acc: "+accNumber+" Current Balance: "+balance);
				return balance;
			}
		} catch (SQLException e) {
			throw new TableException("Unable to complete your request!");
		}
		return 1;
	}

	@Override
	public long withdrawMoney(long accNumber,long money) throws AccountBalanceException, AccountException, TableException {
		boolean isValid = isAccountValid(accNumber);
		if(isValid == false)
			throw new AccountException("This account number: "+accNumber+" is invalid");
		long balance = 0;
		long minBalance=500;
		String sql1 = "UPDATE Account SET HolderBal = ? WHERE HolderId = ?";
		String sql2 = "SELECT HolderBal FROM Account WHERE HolderId = ? ";
		try {
			//Fetching the balance from the table
			PreparedStatement pstmt = con.prepareStatement(sql2);
			pstmt.setLong(1, accNumber);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
				balance = (int) rs.getLong(1);
			if((balance-money)<minBalance)
				throw new AccountBalanceException("You don't have the sufficient balance for this transaction!");
			else
				balance = balance - money;
			
			//Updating the new balance into the table
			pstmt = con.prepareStatement(sql1);
			pstmt.setLong(1, balance);
			pstmt.setLong(2, accNumber);
			int row = pstmt.executeUpdate();
			if(row == 1) {
				list.add("Money amount:"+money+ " withdrawed from acc: "+accNumber+" Current Balance: "+balance);
				return balance;
			}
		}catch(SQLException e){
			throw new TableException("Unable to complete your request!");
		}
		return balance;
	}

	@Override
	public String fundTransfer(long accNumber,long receiverAccNumber, long money) throws AccountBalanceException, AccountException, TableException{
		//Validating user account
		boolean isValid = isAccountValid(accNumber);
		if(isValid == false)
			throw new AccountException("This account number: "+accNumber+" is invalid");
		//Validating receiver account
		isValid = isAccountValid(receiverAccNumber);
		if(isValid == false)
			throw new AccountException("This account number: "+receiverAccNumber+" is invalid");
		long balance = withdrawMoney(accNumber,money);
		depositMoney(receiverAccNumber,money);
		list.add("Money amount:"+money+ " diposited to acc: "+receiverAccNumber+" Current Balance: "+balance);
		return "Succefully transferred";
	}

	@Override
	public ArrayList<String> showTransactions(long accNumber) {
		return list;
	}
	
	@Override
	public long showBalance(long accNumber) throws AccountException, TableException {
		long balance =0;
		boolean isValid = isAccountValid(accNumber);
		if(isValid == false)
			throw new AccountException("This account number: "+accNumber+" is invalid");
		String sql = "Select HolderBal from Account where HolderId = ? ";
		try{
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setLong(1, accNumber);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next())
				balance = rs.getLong(1);
		}catch(SQLException e){
			throw new TableException("Unable to complete your request!");
		}
		return balance;
	}

	@Override
	public AccountHolder showDetails(long accNumber) throws AccountException, TableException{
		boolean isValid = isAccountValid(accNumber);
		if(isValid == false)
			throw new AccountException("This account number: "+accNumber+" is invalid");
		String sql = "Select HolderId, HolderName, HolderGender,HolderDOB, HolderPanNumber, HolderNumber, HolderAddress from Account where HolderId=?";
		try{
			PreparedStatement stmt = con.prepareStatement(sql);
			stmt.setLong(1, accNumber);
			ResultSet rs = stmt.executeQuery();
			if(rs.next()){
				AccountHolder acc= new AccountHolder();
				acc.setAccNumber(rs.getLong("HolderId"));
				acc.setAccHolderName(rs.getString("HolderName"));
				acc.setGender(rs.getString("HolderGender"));
				acc.setDate(rs.getString("HolderDOB"));
				acc.setPanNumber(rs.getString("HolderPanNumber"));
				acc.setPhoneNo(rs.getLong("HolderNumber"));
				acc.setAccHolderAddr("HolderAddress");
				return acc;
			}
		}catch(SQLException e){
			throw new TableException("Unable to complete your request!");
		}
		return null;
	}
	
	boolean isAccountValid(long accNumber) throws TableException{
		boolean isValid = true;
		String sql1 = "Select HolderId from Account";
		try{
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql1);
			while(rs.next())
				accNo.add(rs.getLong(1));
			isValid = accNo.contains(accNumber);
		}catch(SQLException e) {
			throw new TableException("Unable to complete your request!");
		}
		return isValid;
	}
}