package com.cg.dao;

import java.util.ArrayList;

import com.cg.bean.AccountHolder;
import com.cg.exception.AccountBalanceException;
import com.cg.exception.AccountCreateException;
import com.cg.exception.AccountException;
import com.cg.exception.TableException;

public interface AccountDao {
	public long addAccount(AccountHolder acc) throws AccountCreateException, TableException;
	public long depositMoney(long accNumber,long money) throws AccountException, TableException;
	public long withdrawMoney(long accNumber,long money) throws AccountException, AccountBalanceException, TableException;
	public String fundTransfer(long accNumber,long receiverAccNumber, long money) throws AccountException, AccountBalanceException, TableException;
	public ArrayList<String> showTransactions(long accNumber);
	public long showBalance(long accNumber) throws AccountException, TableException;
	public AccountHolder showDetails(long accHolder) throws AccountException, TableException;
}