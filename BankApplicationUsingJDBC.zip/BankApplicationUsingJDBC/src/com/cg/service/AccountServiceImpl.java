package com.cg.service;

import java.util.ArrayList;

import com.cg.bean.AccountHolder;
import com.cg.dao.AccountDao;
import com.cg.dao.AccountDaoImpl;
import com.cg.exception.AccountBalanceException;
import com.cg.exception.AccountCreateException;
import com.cg.exception.AccountException;
import com.cg.exception.TableException;

public class AccountServiceImpl implements AccountService {
	
	AccountDao dao;
	public AccountServiceImpl()
	{
		dao = new AccountDaoImpl();
	}
	@Override
	public long addAccount(AccountHolder acc)throws AccountCreateException, TableException{
		return dao.addAccount(acc);
	}
	
	@Override
	public long depositMoney(long accNumber, long money) throws AccountException, TableException {
		return dao.depositMoney(accNumber,money);
	}

	@Override
	public long withdrawMoney(long accNumber, long money) throws AccountException, AccountBalanceException, TableException {
		return dao.withdrawMoney(accNumber,money);
	}

	@Override
	public String fundTransfer(long accNumber,long receiverAccNumber, long money) throws AccountException, AccountBalanceException, TableException{
		return dao.fundTransfer(accNumber, receiverAccNumber, money);
	}

	@Override
	public ArrayList<String> showTransactions(long accNumber) {	
		return dao.showTransactions(accNumber);
	}

	@Override
	public long showBalance(long accNumber) throws AccountException, TableException{
		return dao.showBalance(accNumber);
	}
	
	@Override
	public AccountHolder showDetails(long accNumber) throws AccountException, TableException{
		return dao.showDetails(accNumber);
	}
	
	public boolean validateName(String name) {
		String nameformat = "[A-Z][a-z]{1,20}";
		if(name.matches(nameformat))
			return true;
		else
			return false;
	}
	public boolean validatePanDetails(String panNumber) {
		String panNumberFormat="[A-Z]{1,6}[0-9]{1,6}";
		if(panNumber.matches(panNumberFormat))
			return true;
		else
			return false;
	}
	public boolean validatePhoneNumber(long phoneNo) {
		String phoneNoFormat ="[0-9]{10}";
		if(Long.toString(phoneNo).matches(phoneNoFormat))
			return true;
		else
			return false;
	}
	public boolean validateAddress(String addr) {
		String addressFormat = "[A-Z][a-z]{1,20}";
		if(addr.matches(addressFormat))
			return true;
		else
			return false;
	}
	public boolean validateGender(String gender) {
		String genderFormat = "[M,F]";
		if(gender.matches(genderFormat))	
			return true;
		else
			return false;	
	}
	
}