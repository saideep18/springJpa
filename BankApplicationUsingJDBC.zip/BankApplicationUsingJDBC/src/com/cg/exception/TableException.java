package com.cg.exception;

public class TableException extends Exception{
	private static final long serialVersionUID = 1L;
	String msg;
	public TableException(String msg){
		this.msg = msg;
	}
	
	public String getMessage(){
		return msg;
	}
}
