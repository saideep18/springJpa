package com.cg.service;

import java.util.ArrayList;
import com.cg.bean.AccountHolder;
import com.cg.exception.AccountBalanceException;
import com.cg.exception.AccountCreateException;
import com.cg.exception.AccountException;

public interface AccountService {
	public int addAccount(AccountHolder acc) throws AccountCreateException;
	public int depositMoney(int accNumber, int money) throws AccountException;
	public int withdrawMoney(int accNumber,int money) throws AccountException, AccountBalanceException;
	public String fundTransfer(int accNumber,int receiverAccNumber, int money) throws AccountException, AccountBalanceException;
	public ArrayList<String> showTransactions(int accNumber);
	public int showBalance(int accNumber) throws AccountException;
	public AccountHolder showDetails(int accNumber) throws AccountException;
}
