package com.cg.service;

import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.bean.AccountHolder;
import com.cg.dao.AccountDao;
import com.cg.dao.AccountDaoImpl;
import com.cg.exception.AccountBalanceException;
import com.cg.exception.AccountCreateException;
import com.cg.exception.AccountException;

public class AccountServiceImpl implements AccountService {
	
	static Logger logger = Logger.getLogger(AccountServiceImpl.class);
	
	AccountDao dao;
	public AccountServiceImpl()
	{
		dao = new AccountDaoImpl();
	}
	@Override
	public int addAccount(AccountHolder acc)throws AccountCreateException{
		logger.info("Inside addAccount in service");
		return dao.addAccount(acc);
	}
	
	@Override
	public int depositMoney(int accNumber, int money) throws AccountException{
		logger.info("Inside depositMoney in service");
		return dao.depositMoney(accNumber,money);
	}

	@Override
	public int withdrawMoney(int accNumber, int money) throws AccountException, AccountBalanceException{
		logger.info("Inside withdrawMoney in service");
		return dao.withdrawMoney(accNumber,money);
	}

	@Override
	public String fundTransfer(int accNumber,int receiverAccNumber, int money) throws AccountException, AccountBalanceException{
		logger.info("Inside fundTransfer in service");
		return dao.fundTransfer(accNumber, receiverAccNumber, money);
	}

	@Override
	public ArrayList<String> showTransactions(int accNumber) {	
		logger.info("Inside showTransfer in service");
		return dao.showTransactions(accNumber);
	}

	@Override
	public int showBalance(int accNumber) throws AccountException{
		logger.info("Inside showBalance in service");
		return dao.showBalance(accNumber);
	}
	
	@Override
	public AccountHolder showDetails(int accNumber) throws AccountException{
		logger.info("Inside showDetails in service");
		return dao.showDetails(accNumber);
	}
	
	public boolean validateName(String name) {
		logger.info("Validation of name done");
		String nameformat = "[A-Z][a-z]{1,20}";
		if(name.matches(nameformat))
			return true;
		else
			return false;
	}
	
	public boolean validatePanDetails(String panNumber) {
		logger.info("Validation of PAN number done");
		String panNumberFormat="[A-Z]{5}[0-9] {5}";
		if(panNumber.matches(panNumberFormat))
			return true;
		else
			return false;
	}
	public boolean validatePhoneNumber(long phoneNo) {
		logger.info("Validation of phone number done");
		String phoneNoFormat ="[6-9][0-9]{9}";
		if(Long.toString(phoneNo).matches(phoneNoFormat))
			return true;
		else
			return false;
	}
	public boolean validateAddress(String addr) {
		logger.info("Validation of address done");
		String addressFormat = "[A-Z][a-z]{1,20}";
		if(addr.matches(addressFormat))
			return true;
		else
			return false;
	}
	public boolean validateGender(String gender) {
		logger.info("Validation of gender done");
		String genderFormat = "[M,F]";
		if(gender.matches(genderFormat))	
			return true;
		else
			return false;	
	}
	
}